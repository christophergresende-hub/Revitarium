from .agent_template import run as template_run

def run(payload: dict, meta: dict) -> dict:
    out = template_run(payload, meta)
    curvature = out.get("features", {}).get("curvature_estimate", 0)
    risk = "low"
    if curvature > 25:
        risk = "high"
    elif curvature > 15:
        risk = "moderate"
    out["risk_class"] = risk
    out["summary"] = f"assessment done. curvature={curvature}, risk={risk}"
    return out
