"""
Agent template.
Each agent exposes run(payload: dict, meta: dict) -> dict
"""
def run(payload: dict, meta: dict) -> dict:
    patient_id = meta.get("patient_id")
    features = {}
    if "images" in payload:
        features["curvature_estimate"] = 12.5
    else:
        features["note"] = "no images provided, using default heuristic"
    result = {
        "agent": "template",
        "patient_id": patient_id,
        "features": features,
        "summary": f"computed {len(features)} features"
    }
    return result
