(async function(){

  const visitsRes = await fetch("/api/visits").then(r=>r.json());
  const convRes = await fetch("/api/conversions").then(r=>r.json());

  const visits = visitsRes.data;
  const conversions = convRes.data;

  // Charts
  new Chart(document.getElementById("visitsChart"), {
    type:"line",
    data:{
      labels:['6d','5d','4d','3d','2d','1d','Hoje'],
      datasets:[{
        label:"Visitas",
        data:visits,
        borderColor:"#00f0ff",
        backgroundColor:"rgba(0,224,255,0.20)",
        tension:.4,
        fill:true
      }]
    },
    options:{responsive:true,plugins:{legend:{display:false}}}
  });

  new Chart(document.getElementById("convChart"), {
    type:"bar",
    data:{
      labels:['6d','5d','4d','3d','2d','1d','Hoje'],
      datasets:[{
        label:"Conversões",
        data:conversions,
        backgroundColor:"#00a6ff"
      }]
    },
    options:{responsive:true,plugins:{legend:{display:false}}}
  });

  // Lists
  const lastActions = document.getElementById("lastActions");
  ["Login", "Exportação", "Configuração"].forEach(a=>{
    const li = document.createElement("li");
    li.textContent = a;
    lastActions.appendChild(li);
  });

  const todoForm = document.getElementById("todoForm");
  const todoList = document.getElementById("todoList");

  todoForm.addEventListener("submit", e=>{
    e.preventDefault();
    const v = todoInput.value.trim();
    if(!v) return;
    const li = document.createElement("li");
    li.textContent = v;
    todoList.appendChild(li);
    todoInput.value = "";
  });

  document.getElementById("logoutBtn").onclick = ()=>{
    localStorage.removeItem("rev_user");
    window.location.href = "index.html";
  };

})();
