document.getElementById("loginForm").addEventListener("submit", function(e){
  e.preventDefault();

  const u = user.value.trim();
  const p = pass.value.trim();

  if(u === "" || p === ""){
    alert("Preencha todos os campos");
    return;
  }

  // Mock login global
  if(u === "admin" && p === "123"){
    localStorage.setItem("rev_user", "ok");
    window.location.href = "dashboard.html";
  } else {
    alert("Usuário ou senha incorretos!");
  }
});
