-- migrations/schema.sql

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  email VARCHAR(200) NOT NULL UNIQUE,
  password_hash VARCHAR(200) NOT NULL,
  role VARCHAR(50) DEFAULT 'user',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- tabela simples de histórico de visitas (exemplo)
CREATE TABLE IF NOT EXISTS visits_history (
  id SERIAL PRIMARY KEY,
  date DATE NOT NULL,
  visits INT DEFAULT 0,
  conversions INT DEFAULT 0
);

-- ex: seed de 7 dias (ajuste)
INSERT INTO visits_history (date, visits, conversions)
SELECT CURRENT_DATE - s, (120 + (random()*120)::int), (8 + (random()*25)::int)
FROM generate_series(6,0,-1) s
ON CONFLICT DO NOTHING;
