1) Certifique-se de ter Docker e Docker Compose instalados.
2) Estrutura de pastas: coloque ./agents e ./data no root (data pode ficar vazia).
3) Editar docker-compose.yml se quiser mudar SECRET_KEY e CORS_ALLOW_ORIGINS.
4) Rodar:
   docker compose up --build
5) Testar login:
   curl -X POST http://localhost:8000/login -H "Content-Type: application/json" -d '{"username":"chris","password":"changeme"}'
6) Use token para /start, /status e /result (Authorization: Bearer <token>).
