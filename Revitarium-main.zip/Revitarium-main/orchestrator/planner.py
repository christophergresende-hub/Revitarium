def run(payload: dict, meta: dict) -> dict:
    features = payload.get("features", {})
    curvature = features.get("curvature_estimate", 0)
    plan = {"exercises": [], "intensity": "low"}
    if curvature > 25:
        plan["exercises"] = ["stabilization_core", "side_stretch", "postural_retraining"]
        plan["intensity"] = "moderate"
    elif curvature > 12:
        plan["exercises"] = ["postural_awareness", "mobility_drills"]
        plan["intensity"] = "low"
    else:
        plan["exercises"] = ["maintenance_strength"]
    return {"agent":"planner","plan":plan,"summary":f"plan with {len(plan['exercises'])} exercises"}
