from celery import Celery
import time, os, json
from importlib import import_module

CELERY_BROKER = os.environ.get("CELERY_BROKER_URL", "redis://localhost:6379/0")
CELERY_BACKEND = os.environ.get("CELERY_RESULT_BACKEND", "redis://localhost:6379/0")

celery_app = Celery("agents", broker=CELERY_BROKER, backend=CELERY_BACKEND)
DATA_DIR = "/app/data"
os.makedirs(DATA_DIR, exist_ok=True)

@celery_app.task(bind=True)
def run_agent_task(self, patient_id: str, workflow: str, payload: dict):
    task_id = self.request.id
    tokens = [t.strip() for t in workflow.split(",") if t.strip()]
    state_path = os.path.join(DATA_DIR, f"{task_id}.json")
    state = {"task_id": task_id, "patient_id": patient_id, "workflow": tokens, "progress": []}
    with open(state_path, "w") as f:
        json.dump(state, f)

    current_payload = payload
    for idx, token in enumerate(tokens, start=1):
        agent_file = f"agents.{token}"
        try:
            mod = import_module(agent_file)
            result = mod.run(current_payload, meta={"patient_id": patient_id})
        except Exception as e:
            state["progress"].append({"agent": token, "status":"failed","error": str(e)})
            with open(state_path, "w") as f:
                json.dump(state, f)
            raise

        state["progress"].append({"agent": token, "status":"done","output_summary": result.get("summary") if isinstance(result, dict) else None})
        with open(state_path, "w") as f:
            json.dump(state, f)
        current_payload = result if isinstance(result, dict) else {"result": result}
        time.sleep(0.2)

    state["final"] = current_payload
    with open(state_path, "w") as f:
        json.dump(state, f)
    return current_payload
