import os
import json
from datetime import datetime, timedelta
from typing import Optional
from passlib.context import CryptContext
from jose import JWTError, jwt

DATA_DIR = "/app/data"
os.makedirs(DATA_DIR, exist_ok=True)
USERS_FILE = os.path.join(DATA_DIR, "users.json")

SECRET_KEY = os.environ.get("SECRET_KEY", "PLEASE_CHANGE_THIS_SECRET_IN_PROD")
ALGORITHM = os.environ.get("JWT_ALGORITHM", "HS256")
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.environ.get("ACCESS_TOKEN_EXPIRE_MINUTES", "120"))

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def _ensure_users():
    if not os.path.exists(USERS_FILE):
        default = {
            "chris": {
                "username": "chris",
                "hashed_password": pwd_context.hash("changeme"),
                "full_name": "Christopher",
                "disabled": False
            }
        }
        with open(USERS_FILE, "w") as f:
            json.dump(default, f, indent=2)

def load_user(username: str) -> Optional[dict]:
    _ensure_users()
    with open(USERS_FILE, "r") as f:
        data = json.load(f)
    return data.get(username)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def authenticate_user(username: str, password: str):
    user = load_user(username)
    if not user:
        return None
    if not verify_password(password, user["hashed_password"]):
        return None
    return user

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta if expires_delta else timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

def decode_token(token: str):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        return None
