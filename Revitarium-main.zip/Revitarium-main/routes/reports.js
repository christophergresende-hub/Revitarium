// routes/reports.js
const express = require('express');
const router = express.Router();
const db = require('../db');
const authenticate = require('../middleware/auth');

// mock endpoint: visits last N days
router.get('/visits', authenticate, async (req, res) => {
  try {
    const range = parseInt(req.query.range || '7', 10);
    // exemplo simples: buscar do banco (substitua por consultas reais)
    const rows = await db.query(
      `SELECT date::text as day, visits FROM visits_history WHERE date >= CURRENT_DATE - $1::int ORDER BY date ASC`,
      [range - 1]
    );
    res.json({ data: rows.rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Could not fetch visits' });
  }
});

// endpoint de export CSV (exemplo)
router.get('/export', authenticate, async (req, res) => {
  try {
    // monta CSV simples
    const { rows } = await db.query('SELECT date::text as day, visits, conversions FROM visits_history ORDER BY date ASC LIMIT 1000');
    const header = 'day,visits,conversions\n';
    const csv = header + rows.map(r => `${r.day},${r.visits},${r.conversions}`).join('\n');
    res.setHeader('Content-disposition', 'attachment; filename=revitarium-export.csv');
    res.setHeader('Content-Type', 'text/csv');
    res.send(csv);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Export failed' });
  }
});

// Exemplo: stats rápidas
router.get('/stats', authenticate, async (req, res) => {
  try {
    const users = await db.query('SELECT COUNT(*)::int AS total_users FROM users');
    const sessions = await db.query('SELECT COUNT(*)::int AS total_sessions FROM sessions'); // se tiver tabela sessions
    res.json({
      total_users: users.rows[0].total_users || 0,
      total_sessions: sessions.rows[0] ? sessions.rows[0].total_sessions : 0
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Stats failed' });
  }
});

module.exports = router;
